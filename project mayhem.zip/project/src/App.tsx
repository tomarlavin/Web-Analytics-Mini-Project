import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { ShoppingCart, Heart, Activity, Users, DollarSign, BarChart3, Store, Star, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';

// Types
interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  likes: number;
  description: string;
  category: string;
}

interface Analytics {
  totalVisits: number;
  averageTimeSpent: number;
  totalPurchases: number;
  likedProducts: number;
  conversionRate: number;
  dailyVisits: { date: string; visits: number }[];
  productPerformance: { name: string; purchases: number; likes: number }[];
  lastUpdated: string;
}

const COLORS = ['#FF0066', '#00C49F', '#FFBB28', '#FF8042'];

const PARTNERS = [
  { name: 'Nike', logo: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff' },
  { name: 'Adidas', logo: 'https://images.unsplash.com/photo-1544441893-675973e31985' },
  { name: 'Puma', logo: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5' },
  { name: 'Under Armour', logo: 'https://images.unsplash.com/photo-1556906781-9a412961c28c' }
];

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [sessionStartTime] = useState(new Date());
  const [products] = useState<Product[]>([
    {
      id: 1,
      name: "Cyberpunk Combat Boots",
      price: 149.99,
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
      likes: 45,
      description: "Futuristic combat boots with neon accents",
      category: "Shoes"
    },
    {
      id: 2,
      name: "Neon Runner X-89",
      price: 129.99,
      image: "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2",
      likes: 38,
      description: "High-performance running shoes with LED soles",
      category: "Shoes"
    },
    {
      id: 3,
      name: "Digital Disruption Tee",
      price: 39.99,
      image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27",
      likes: 52,
      description: "Glitch art graphic t-shirt",
      category: "T-Shirts"
    },
    {
      id: 4,
      name: "Matrix High Tops",
      price: 159.99,
      image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a",
      likes: 41,
      description: "High-top sneakers with matrix code print",
      category: "Shoes"
    },
    {
      id: 5,
      name: "Resistance Tactical Boots",
      price: 189.99,
      image: "https://images.unsplash.com/photo-1605812860427-4024433a70fd",
      likes: 33,
      description: "Heavy-duty tactical boots with reinforced soles",
      category: "Shoes"
    },
    {
      id: 6,
      name: "Anarchist Print Tee",
      price: 34.99,
      image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a",
      likes: 47,
      description: "Distressed anarchist symbol t-shirt",
      category: "T-Shirts"
    },
    {
      id: 7,
      name: "Ghost in the Machine Tee",
      price: 39.99,
      image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27",
      likes: 39,
      description: "Abstract digital art t-shirt",
      category: "T-Shirts"
    },
    {
      id: 8,
      name: "System Override Sneakers",
      price: 144.99,
      image: "https://images.unsplash.com/photo-1595341888016-a392ef81b7de",
      likes: 55,
      description: "Futuristic low-top sneakers",
      category: "Shoes"
    },
    {
      id: 9,
      name: "Binary Code Tee",
      price: 35.99,
      image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a",
      likes: 43,
      description: "Binary code pattern t-shirt",
      category: "T-Shirts"
    },
    {
      id: 10,
      name: "Stealth Ops Boots",
      price: 179.99,
      image: "https://images.unsplash.com/photo-1605812860427-4024433a70fd",
      likes: 51,
      description: "Matte black tactical boots",
      category: "Shoes"
    }
  ]);

  const [analytics, setAnalytics] = useState<Analytics>({
    totalVisits: 0,
    averageTimeSpent: 0,
    totalPurchases: 0,
    likedProducts: 0,
    conversionRate: 0,
    dailyVisits: [],
    productPerformance: [],
    lastUpdated: new Date().toISOString()
  });

  const [cart, setCart] = useState<number[]>([]);
  const [likedProducts, setLikedProducts] = useState<number[]>([]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split('T')[0];
    }).reverse();

    setAnalytics(prev => ({
      ...prev,
      totalVisits: prev.totalVisits + 1,
      dailyVisits: last7Days.map(date => ({
        date,
        visits: date === today ? prev.totalVisits + 1 : Math.floor(Math.random() * 100)
      })),
      productPerformance: [
        { name: 'T-Shirts', purchases: 0, likes: 0 },
        { name: 'Shoes', purchases: 0, likes: 0 }
      ]
    }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const currentTime = new Date();
      const timeSpent = (currentTime.getTime() - sessionStartTime.getTime()) / 1000 / 60;
      
      setAnalytics(prev => ({
        ...prev,
        averageTimeSpent: timeSpent,
        lastUpdated: currentTime.toISOString()
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, [sessionStartTime]);

  const updateProductPerformance = (productId: number, type: 'purchase' | 'like') => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    setAnalytics(prev => {
      const updatedPerformance = prev.productPerformance.map(category => {
        if (category.name === product.category) {
          return {
            ...category,
            [type === 'purchase' ? 'purchases' : 'likes']: category[type === 'purchase' ? 'purchases' : 'likes'] + 1
          };
        }
        return category;
      });

      return {
        ...prev,
        productPerformance: updatedPerformance,
        lastUpdated: new Date().toISOString()
      };
    });
  };

  const toggleLike = (productId: number) => {
    const isLiked = likedProducts.includes(productId);
    setLikedProducts(prev => 
      isLiked ? prev.filter(id => id !== productId) : [...prev, productId]
    );
    
    if (!isLiked) {
      updateProductPerformance(productId, 'like');
      setAnalytics(prev => ({
        ...prev,
        likedProducts: prev.likedProducts + 1,
        lastUpdated: new Date().toISOString()
      }));
    }
  };

  const addToCart = (productId: number) => {
    setCart(prev => [...prev, productId]);
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(id => id !== productId));
  };

  const checkout = () => {
    cart.forEach(productId => {
      updateProductPerformance(productId, 'purchase');
    });

    setAnalytics(prev => {
      const newPurchases = prev.totalPurchases + cart.length;
      return {
        ...prev,
        totalPurchases: newPurchases,
        conversionRate: (newPurchases / prev.totalVisits) * 100,
        lastUpdated: new Date().toISOString()
      };
    });
    
    setCart([]);
    alert('Purchase successful!');
  };

  const Navigation = () => {
    const cartTotal = cart.reduce((total, productId) => {
      const product = products.find(p => p.id === productId);
      return total + (product?.price || 0);
    }, 0);

    return (
      <nav className="bg-mayhem-darker shadow-lg sticky top-0 z-50 border-b border-mayhem-pink/20">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Store className="w-6 h-6 text-mayhem-pink" />
            <h1 className="text-xl font-bold text-white glitch-effect">PROJECT MAYHEM</h1>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/favorites" className="p-2 relative hover-glow rounded-full">
              <Heart className="w-6 h-6 text-white" />
              {likedProducts.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-mayhem-pink text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {likedProducts.length}
                </span>
              )}
            </Link>
            <Link to="/cart" className="p-2 relative hover-glow rounded-full">
              <ShoppingCart className="w-6 h-6 text-white" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-mayhem-pink text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </Link>
            <button 
              onClick={() => setIsAdmin(true)}
              className="text-sm text-white hover:text-mayhem-pink transition-colors"
            >
              Admin
            </button>
          </div>
        </div>
      </nav>
    );
  };

  const Hero = () => (
    <div className="bg-mayhem-darker relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-mayhem-pink/20 to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 py-16 md:py-24 relative">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 glitch-effect">
            DIGITAL REBELLION
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Break free from conformity with our cyberpunk-inspired collection
          </p>
          <div className="flex gap-4 justify-center">
            <div className="bg-mayhem-gray/50 backdrop-blur-sm rounded-lg p-4 text-center border border-mayhem-pink/30">
              <p className="text-2xl font-bold text-mayhem-pink">50%</p>
              <p className="text-sm">Off</p>
            </div>
            <div className="bg-mayhem-gray/50 backdrop-blur-sm rounded-lg p-4 text-center border border-mayhem-pink/30">
              <p className="text-2xl font-bold text-mayhem-pink">24H</p>
              <p className="text-sm">Flash Sale</p>
            </div>
            <div className="bg-mayhem-gray/50 backdrop-blur-sm rounded-lg p-4 text-center border border-mayhem-pink/30">
              <p className="text-2xl font-bold text-mayhem-pink">NEW</p>
              <p className="text-sm">Collection</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const ProductGrid = ({ filteredProducts = products }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {filteredProducts.map(product => (
        <div key={product.id} className="product-card rounded-lg overflow-hidden border border-mayhem-pink/20">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-64 object-cover"
          />
          <div className="p-4">
            <h3 className="text-lg font-semibold text-white">{product.name}</h3>
            <p className="text-mayhem-pink">${product.price}</p>
            <p className="text-sm text-gray-400 mt-1">{product.description}</p>
            <div className="mt-4 flex justify-between items-center">
              <button
                onClick={() => toggleLike(product.id)}
                className={`p-2 rounded-full transition-colors ${
                  likedProducts.includes(product.id) 
                    ? 'text-mayhem-pink bg-mayhem-pink/20' 
                    : 'text-gray-400 hover:text-mayhem-pink'
                }`}
              >
                <Heart className="w-5 h-5" />
              </button>
              <button
                onClick={() => addToCart(product.id)}
                className="cyber-button px-4 py-2 rounded-md"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const AboutSection = () => (
    <div className="bg-mayhem-gray py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white glitch-effect">About Project Mayhem</h2>
          <p className="mt-4 text-lg text-gray-400">
            Redefining streetwear since 2024
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-mayhem-pink/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-8 h-8 text-mayhem-pink" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white">Premium Quality</h3>
            <p className="text-gray-400">Crafted for the digital age</p>
          </div>
          <div className="text-center">
            <div className="bg-mayhem-pink/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingCart className="w-8 h-8 text-mayhem-pink" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white">Fast Shipping</h3>
            <p className="text-gray-400">From our dimension to yours</p>
          </div>
          <div className="text-center">
            <div className="bg-mayhem-pink/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-mayhem-pink" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white">Customer Love</h3>
            <p className="text-gray-400">Join the revolution</p>
          </div>
        </div>
      </div>
    </div>
  );

  const PartnersSection = () => (
    <div className="bg-mayhem-darker py-16">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-white mb-12 glitch-effect">Our Partners</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {PARTNERS.map(partner => (
            <div key={partner.name} className="flex items-center justify-center">
              <img 
                src={partner.logo} 
                alt={partner.name}
                className="h-16 object-contain grayscale hover:grayscale-0 transition-all hover-glow"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const Footer = () => (
    <footer className="bg-mayhem-darker text-white border-t border-mayhem-pink/20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4 text-mayhem-pink">About Us</h3>
            <p className="text-gray-400">
              Project Mayhem is your gateway to cyberpunk-inspired streetwear and footwear.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-mayhem-pink">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white">Home</Link></li>
              <li><Link to="/favorites" className="text-gray-400 hover:text-white">Favorites</Link></li>
              <li><Link to="/cart" className="text-gray-400 hover:text-white">Cart</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-mayhem-pink">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Email: contact@projectmayhem.com</li>
              <li>Phone: (555) 123-4567</li>
              <li>Address: 123 Cyber St, Digital City</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-mayhem-pink">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white hover-glow">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white hover-glow">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white hover-glow">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white hover-glow">
                <Linkedin className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-mayhem-pink/20 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Project Mayhem. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );

  const HomePage = () => (
    <div>
      <Hero />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold text-white mb-6 glitch-effect">Featured Collection</h2>
        <ProductGrid />
      </div>
      <AboutSection />
      <PartnersSection />
      <Footer />
    </div>
  );

  const FavoritesPage = () => {
    const favoriteProducts = products.filter(product => likedProducts.includes(product.id));
    
    return (
      <div>
        <div className="max-w-7xl mx-auto px-4 py-8">
          <h2 className="text-2xl font-bold text-white mb-6 glitch-effect">Favorite Items</h2>
          {favoriteProducts.length > 0 ? (
            <ProductGrid filteredProducts={favoriteProducts} />
          ) : (
            <p className="text-gray-400 text-center">No favorite items yet.</p>
          )}
        </div>
        <Footer />
      </div>
    );
  };

  const CartPage = () => {
    const cartProducts = products.filter(product => cart.includes(product.id));
    const total = cartProducts.reduce((sum, product) => sum + product.price, 0);
    
    return (
      <div>
        <div className="max-w-7xl mx-auto px-4 py-8">
          <h2 className="text-2xl font-bold text-white mb-6 glitch-effect">Shopping Cart</h2>
          {cartProducts.length > 0 ? (
            <div>
              <div className="bg-mayhem-gray rounded-lg overflow-hidden border border-mayhem-pink/20">
                {cartProducts.map(product => (
                  <div key={product.id} className="flex items-center p-4 border-b border-mayhem-pink/20">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-20 h-20 object-cover rounded"
                    />
                    <div className="ml-4 flex-1">
                      <h3 className="text-lg font-semibold text-white">{product.name}</h3>
                      <p className="text-mayhem-pink">${product.price}</p>
                    </div>
                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="text-mayhem-pink hover:text-red-500"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
              <div className="mt-6 bg-mayhem-gray rounded-lg p-6 border border-mayhem-pink/20">
                <div className="flex justify-between text-lg font-semibold text-white">
                  <span>Total:</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <button
                  onClick={checkout}
                  className="mt-4 w-full cyber-button py-2 rounded-md"
                >
                  Checkout
                </button>
              </div>
            </div>
          ) : (
            <p className="text-gray-400 text-center">Your cart is empty.</p>
          )}
        </div>
        <Footer />
      </div>
    );
  };

  const AdminView = () => (
    <div className="min-h-screen bg-mayhem-darker">
      <nav className="bg-mayhem-gray border-b border-mayhem-pink/20">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-mayhem-pink glitch-effect">Admin Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">
              Last updated: {new Date(analytics.lastUpdated).toLocaleTimeString()}
            </span>
            <button 
              onClick={() => setIsAdmin(false)}
              className="text-sm text-gray-400 hover:text-white"
            >
              Back to Store
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-400 text-sm">Total Visits</h3>
              <Users className="w-5 h-5 text-mayhem-pink" />
            </div>
            <p className="text-2xl font-bold text-white mt-2">{analytics.totalVisits}</p>
          </div>

          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-400 text-sm">Avg. Time (min)</h3>
              <Activity className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white mt-2">
              {analytics.averageTimeSpent.toFixed(1)}
            </p>
          </div>

          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-400 text-sm">Purchases</h3>
              <DollarSign className="w-5 h-5 text-blue-400" />
            </div>
            <p className="text-2xl font-bold text-white mt-2">{analytics.totalPurchases}</p>
          </div>

          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-400 text-sm">Conversion Rate</h3>
              <BarChart3 className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-2xl font-bold text-white mt-2">
              {analytics.conversionRate.toFixed(1)}%
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <h3 className="text-lg font-semibold text-white mb-4">Daily Visits</h3>
            <div className="h-64">
              <LineChart width={500} height={250} data={analytics.dailyVisits}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                <XAxis dataKey="date" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1A1A1A',
                    border: '1px solid rgba(255, 0, 102, 0.2)',
                    color: '#fff'
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="visits" stroke="#FF0066" />
              </LineChart>
            </div>
          </div>

          <div className="bg-mayhem-gray p-6 rounded-lg border border-mayhem-pink/20">
            <h3 className="text-lg font-semibold text-white mb-4">Product Category Performance</h3>
            <div className="h-64">
              <PieChart width={400} height={250}>
                <Pie
                  data={analytics.productPerformance}
                  dataKey="purchases"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label
                >
                  {analytics.productPerformance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1A1A1A',
                    border: '1px solid rgba(255, 0, 102, 0.2)',
                    color: '#fff'
                  }}
                />
                <Legend />
              </PieChart>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const UserView = () => (
    <div className="min-h-screen bg-mayhem-dark">
      <Navigation />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
    </div>
  );

  return (
    <Router>
      {isAdmin ? <AdminView /> : <UserView />}
    </Router>
  );
}

export default App;